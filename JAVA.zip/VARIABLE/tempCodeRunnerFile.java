public class String_Replace {
    public static void main(String[] args) {
        String name = "Ashish";
        System.out.println(name.replace(A, R));

    }
}
